//
//  ViewController.swift
//  animacion_practica
//
//  Created by Maestro on 17/01/18.
//  Copyright © 2018 Maestro. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var vwLogo: UIImageView!
    @IBOutlet weak var lblUsuario: UILabel!
    @IBOutlet weak var lblPassword: UILabel!
    @IBOutlet weak var txtUsuario: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    @IBOutlet weak var lblSesion: UILabel!
    @IBOutlet weak var lblRegistro: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func viewWillAppear(_ animated: Bool) {
        
        self.lblUsuario.center.x -= 300
        self.lblPassword.center.x -= 300
        self.txtUsuario.center.x -= 300
        self.txtPassword.center.x -= 300
        
        self.lblSesion.alpha = 1
        self.lblRegistro.alpha = 1
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        UIView.animate(withDuration: 1.5, delay : 0, options : [.curveEaseIn], animations: {
            
            //self.vwLogo.transform = CGAffineTransform(rotationAngle: CGFloat (270.0 * M_PI / 180.0 ))
            self.vwLogo.transform = CGAffineTransform(scaleX: 1.0, y: 1.0)
            
            self.lblUsuario.center.x += 300
            self.lblPassword.center.x += 300
            self.txtUsuario.center.x += 300
            self.txtPassword.center.x += 300
            
        }, completion: nil)
    
        //UIView.animate(withDuration: 1.0, animations: {
            
        //})
        
    }
    
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

